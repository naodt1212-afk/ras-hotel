package com.example.ui.screens

import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.example.data.model.BookingEntity
import com.example.data.model.FavoriteEntity
import com.example.ui.theme.*
import com.example.ui.translation.AppLanguage
import com.example.ui.translation.Translation
import com.example.ui.viewmodel.HotelRoom
import com.example.ui.viewmodel.HotelScreen
import com.example.ui.viewmodel.HotelViewModel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen(viewModel: HotelViewModel) {
    val coroutineScope = rememberCoroutineScope()
    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    val context = LocalContext.current

    // State bindings from flow
    val currentLang by viewModel.currentLanguage.collectAsStateWithLifecycle()
    val activeScreen by viewModel.activeScreen.collectAsStateWithLifecycle()
    val bookings by viewModel.allBookings.collectAsStateWithLifecycle()
    val favorites by viewModel.allFavorites.collectAsStateWithLifecycle()
    val currentUser by viewModel.currentUser.collectAsStateWithLifecycle()

    var showLanguageDialog by remember { mutableStateOf(false) }
    var activeRoomForPayment by remember { mutableStateOf<HotelRoom?>(null) }
    var showVideoDialog by remember { mutableStateOf(false) }

    // Nav Drawer Options list mapped to translate key + icon + route screen
    val navigationItems = listOf(
        Triple("Home", Icons.Default.Home, HotelScreen.Home),
        Triple("About Us", Icons.Default.History, HotelScreen.About),
        Triple("Rooms", Icons.Default.Bed, HotelScreen.Rooms),
        Triple("Services", Icons.Default.RoomService, HotelScreen.Services),
        Triple("Gallery", Icons.Default.Collections, HotelScreen.Gallery),
        Triple("Restaurant & Dining", Icons.Default.Restaurant, HotelScreen.Dining),
        Triple("Events & Meetings", Icons.Default.Groups, HotelScreen.Events),
        Triple("Offers", Icons.Default.LocalOffer, HotelScreen.Offers),
        Triple("Booking", Icons.Default.CalendarMonth, HotelScreen.Booking),
        Triple("Contact", Icons.Default.Email, HotelScreen.Contact),
        Triple("Login / Signup", Icons.Default.AccountCircle, HotelScreen.Auth),
        Triple("User Dashboard", Icons.Default.Dashboard, HotelScreen.Dashboard)
    )

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            ModalDrawerSheet(
                drawerContainerColor = LuxuryDarkGreen,
                drawerContentColor = LuxuryTextLight,
                modifier = Modifier.width(310.dp)
            ) {
                // Royal Drawer Header
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(
                            Brush.verticalGradient(
                                colors = listOf(Color(0xFF030D08), LuxuryLightGreen)
                            )
                        )
                        .padding(horizontal = 24.dp, vertical = 32.dp)
                ) {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "⚜️",
                                fontSize = 26.sp,
                                modifier = Modifier.padding(end = 8.dp)
                            )
                            Text(
                                text = Translation.get("app_title", currentLang).uppercase(),
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Black,
                                color = LuxuryGold,
                                letterSpacing = 2.sp
                            )
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = Translation.get("tagline", currentLang),
                            fontSize = 11.sp,
                            fontStyle = FontStyle.Italic,
                            fontWeight = FontWeight.Medium,
                            color = LuxuryTextMuted
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                "Five-Star Rating",
                                fontSize = 10.sp,
                                color = LuxuryTextMuted
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("⭐⭐⭐⭐⭐", fontSize = 11.sp)
                        }
                    }
                }

                Divider(color = LuxuryGold.copy(alpha = 0.3f), thickness = 1.dp)

                // Scrollable nav list
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    items(navigationItems) { item ->
                        val isSelected = activeScreen == item.third
                        NavigationDrawerItem(
                            icon = {
                                Icon(
                                    imageVector = item.second,
                                    contentDescription = item.first,
                                    tint = if (isSelected) LuxuryLightText else LuxuryGold
                                )
                            },
                            label = {
                                Text(
                                    text = when (item.third) {
                                        HotelScreen.Home -> Translation.get("app_title", currentLang)
                                        HotelScreen.About -> Translation.get("about_title", currentLang).take(20) + "..."
                                        HotelScreen.Rooms -> Translation.get("rooms_title", currentLang)
                                        HotelScreen.Services -> Translation.get("services_title", currentLang)
                                        HotelScreen.Gallery -> Translation.get("gallery", currentLang)
                                        HotelScreen.Dining -> Translation.get("dining_section", currentLang)
                                        HotelScreen.Events -> Translation.get("events_meetings", currentLang)
                                        HotelScreen.Offers -> Translation.get("offers", currentLang)
                                        HotelScreen.Booking -> Translation.get("book_now", currentLang)
                                        HotelScreen.Contact -> Translation.get("contact", currentLang)
                                        HotelScreen.Auth -> if (currentUser != null) Translation.get("user_dashboard", currentLang) else Translation.get("login_signup", currentLang)
                                        HotelScreen.Dashboard -> Translation.get("user_dashboard", currentLang)
                                        else -> item.first
                                    },
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                    fontSize = 14.sp
                                )
                            },
                            selected = isSelected,
                            onClick = {
                                viewModel.navigateTo(item.third)
                                coroutineScope.launch { drawerState.close() }
                            },
                            colors = NavigationDrawerItemDefaults.colors(
                                selectedContainerColor = LuxuryGold,
                                selectedTextColor = LuxuryLightText,
                                unselectedContainerColor = Color.Transparent,
                                unselectedTextColor = LuxuryTextLight
                            ),
                            modifier = Modifier
                                .testTag("nav_item_${item.first.lowercase().replace(" ", "_")}")
                                .clip(RoundedCornerShape(8.dp))
                        )
                    }

                    // Logout extra context inside Drawer
                    if (currentUser != null) {
                        item {
                            Spacer(modifier = Modifier.height(16.dp))
                            Button(
                                onClick = {
                                    viewModel.logout()
                                    coroutineScope.launch { drawerState.close() }
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF8B0000)),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 8.dp),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Icon(
                                    Icons.Default.Logout,
                                    contentDescription = null,
                                    tint = Color.White,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    Translation.get("logout", currentLang),
                                    fontSize = 12.sp,
                                    color = Color.White
                                )
                            }
                        }
                    }
                }
            }
        }
    ) {
        Scaffold(
            topBar = {
                CenterAlignedTopAppBar(
                    title = {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(
                                text = Translation.get("app_title", currentLang).uppercase(),
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Black,
                                color = LuxuryGold,
                                letterSpacing = 1.5.sp
                            )
                            Text(
                                text = Translation.get("tagline", currentLang),
                                fontSize = 9.sp,
                                color = LuxuryTextMuted,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    },
                    navigationIcon = {
                        IconButton(
                            onClick = { coroutineScope.launch { drawerState.open() } },
                            modifier = Modifier.testTag("drawer_hamburger")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Menu,
                                contentDescription = "Navigation Menu",
                                tint = LuxuryGold
                            )
                        }
                    },
                    actions = {
                        // Language switcher button
                        TextButton(
                            onClick = { showLanguageDialog = true },
                            colors = ButtonDefaults.textButtonColors(contentColor = LuxuryGold),
                            modifier = Modifier.testTag("lang_selector_btn")
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = currentLang.flag,
                                    fontSize = 16.sp
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = currentLang.code.uppercase(),
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Icon(
                                    imageVector = Icons.Default.ArrowDropDown,
                                    contentDescription = null,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }
                    },
                    colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                        containerColor = LuxuryDarkGreen,
                        titleContentColor = LuxuryTextLight
                    )
                )
            },
            floatingActionButton = {
                // Floating WhatsApp FAB
                FloatingActionButton(
                    onClick = {
                        // Launch WhatsApp dialer
                        val intent = Intent(Intent.ACTION_VIEW).apply {
                            data = Uri.parse("https://wa.me/251251113000")
                        }
                        try {
                            context.startActivity(intent)
                        } catch (e: Exception) {
                            Toast.makeText(context, "Directing to Concierge desk: +251 25 111 3000", Toast.LENGTH_SHORT).show()
                        }
                    },
                    containerColor = Color(0xFF25D366),
                    contentColor = Color.White,
                    shape = CircleShape,
                    modifier = Modifier
                        .padding(bottom = 16.dp, end = 8.dp)
                        .testTag("whatsapp_fab")
                ) {
                    Box(modifier = Modifier.padding(14.dp)) {
                        Icon(
                            imageVector = Icons.Default.Chat,
                            contentDescription = "Contact Dedicated Concierge WhatsApp",
                            modifier = Modifier.size(24.dp)
                        )
                    }
                }
            },
            contentWindowInsets = WindowInsets.safeDrawing
        ) { innerPadding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .background(MaterialTheme.colorScheme.background)
            ) {
                // Smooth slide/fade rendering based on active screen
                Crossfade(targetState = activeScreen, label = "ScreenTransition") { screen ->
                    when (screen) {
                        is HotelScreen.Home -> HomeSection(
                            viewModel = viewModel,
                            lang = currentLang,
                            onBookNow = {
                                viewModel.navigateTo(HotelScreen.Booking)
                            },
                            onWatchVideo = {
                                showVideoDialog = true
                            }
                        )

                        is HotelScreen.About -> AboutSection(lang = currentLang)

                        is HotelScreen.Rooms -> RoomsSection(
                            viewModel = viewModel,
                            lang = currentLang,
                            favorites = favorites,
                            onBookNow = { room ->
                                viewModel.selectedBookingRoom.value = room
                                activeRoomForPayment = room
                            }
                        )

                        is HotelScreen.Services -> ServicesSection(lang = currentLang)

                        is HotelScreen.Gallery -> GallerySection(lang = currentLang)

                        is HotelScreen.Dining -> DiningSection(lang = currentLang)

                        is HotelScreen.Events -> EventsSection(lang = currentLang)

                        is HotelScreen.Offers -> OffersSection(lang = currentLang)

                        is HotelScreen.Booking -> BookingSection(
                            viewModel = viewModel,
                            lang = currentLang,
                            onTriggerPayment = { room ->
                                activeRoomForPayment = room
                            }
                        )

                        is HotelScreen.Contact -> ContactSection(lang = currentLang)

                        is HotelScreen.Auth -> AuthSection(viewModel = viewModel, lang = currentLang)

                        is HotelScreen.Dashboard -> DashboardSection(
                            viewModel = viewModel,
                            lang = currentLang,
                            favorites = favorites,
                            onBookNow = { room ->
                                viewModel.selectedBookingRoom.value = room
                                activeRoomForPayment = room
                            }
                        )
                    }
                }
            }
        }
    }

    // Modal payment wizard displaying triggers
    activeRoomForPayment?.let { room ->
        PaymentModal(
            room = room,
            lang = currentLang,
            onDismiss = { activeRoomForPayment = null },
            onPaymentConfirmed = { method ->
                viewModel.selectedBookingRoom.value = room
                viewModel.executeBooking(method, "Confirmed")
                activeRoomForPayment = null
                Toast.makeText(context, Translation.get("book_success", currentLang), Toast.LENGTH_LONG).show()
            }
        )
    }

    // Interactive Language Dialog Selector
    if (showLanguageDialog) {
        Dialog(onDismissRequest = { showLanguageDialog = false }) {
            Card(
                colors = CardDefaults.cardColors(containerColor = LuxuryDarkGreen),
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, LuxuryGold)
            ) {
                Column(
                    modifier = Modifier.padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "Select Imperial Language",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = LuxuryGold
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    AppLanguage.values().forEach { langOption ->
                        Surface(
                            onClick = {
                                viewModel.setLanguage(langOption)
                                showLanguageDialog = false
                            },
                            color = if (currentLang == langOption) LuxuryGold else Color.Transparent,
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp)
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(text = langOption.flag, fontSize = 20.sp)
                                Spacer(modifier = Modifier.width(12.dp))
                                Text(
                                    text = langOption.displayName,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (currentLang == langOption) LuxuryLightText else Color.White
                                )
                                Spacer(modifier = Modifier.weight(1f))
                                Text(
                                    text = langOption.code.uppercase(),
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Light,
                                    color = if (currentLang == langOption) LuxuryLightText else LuxuryTextMuted
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    // Simulated Cinema Video player Dialog
    if (showVideoDialog) {
        Dialog(onDismissRequest = { showVideoDialog = false }) {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color.Black),
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(2.dp, LuxuryGold),
                modifier = Modifier.fillMaxWidth().height(260.dp)
            ) {
                Box(modifier = Modifier.fillMaxSize()) {
                    // Back drop hotel photo
                    AsyncImage(
                        model = ImageRequest.Builder(LocalContext.current)
                            .data("https://images.unsplash.com/photo-1542314831-068cd1dbfeeb?auto=format&fit=crop&w=800&q=80")
                            .crossfade(true)
                            .build(),
                        contentDescription = "Ras Hotel Cinematic View",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )

                    // Cinematic Golden Overlay
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(
                                Brush.radialGradient(
                                    colors = listOf(Color.Transparent, Color.Black.copy(alpha = 0.8f))
                                )
                            )
                    )

                    // Closing Button
                    IconButton(
                        onClick = { showVideoDialog = false },
                        modifier = Modifier.align(Alignment.TopEnd).padding(8.dp)
                    ) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = Color.White)
                    }

                    // Playing message central layout
                    Column(
                        modifier = Modifier
                            .align(Alignment.Center)
                            .padding(16.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Surface(
                            modifier = Modifier.size(52.dp),
                            color = LuxuryGold,
                            shape = CircleShape,
                            shadowElevation = 8.dp
                        ) {
                            Icon(
                                imageVector = Icons.Default.PlayArrow,
                                contentDescription = "Playing",
                                tint = Color.Black,
                                modifier = Modifier
                                    .size(36.dp)
                                    .padding(8.dp)
                            )
                        }
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "DIREDAWA RAS HOTEL LEGACY FILM",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = LuxuryGold,
                            letterSpacing = 1.sp,
                            textAlign = TextAlign.Center
                        )
                        Text(
                            text = "A cinematic journey inside traditional Ethiopian hospitality...",
                            fontSize = 11.sp,
                            color = Color.White.copy(alpha = 0.8f),
                            textAlign = TextAlign.Center
                        )
                    }
                }
            }
        }
    }
}

// -------------------------------------------------------------
// 1. HOME SECTION
// -------------------------------------------------------------
@Composable
fun HomeSection(
    viewModel: HotelViewModel,
    lang: AppLanguage,
    onBookNow: () -> Unit,
    onWatchVideo: () -> Unit
) {
    var checkIn by remember { mutableStateOf("2026-05-27") }
    var checkOut by remember { mutableStateOf("2026-05-30") }
    var guestNum by remember { mutableStateOf(2) }

    LazyColumn(
        modifier = Modifier.fillMaxSize()
    ) {
        // Hero section
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(480.dp)
            ) {
                // Large Luxury Background Image (Coil AsyncImage)
                AsyncImage(
                    model = ImageRequest.Builder(LocalContext.current)
                        .data("https://images.unsplash.com/photo-1566073771259-6a8506099945?auto=format&fit=crop&w=1200&q=80")
                        .crossfade(true)
                        .build(),
                    contentDescription = "Diredawa Ras Hotel Facade",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )

                // Dark gold overlay on hero image for high elegance and contrast text readability
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.verticalGradient(
                                colors = listOf(
                                    Color.Black.copy(alpha = 0.7f),
                                    Color(0xFF030E09).copy(alpha = 0.85f)
                                )
                            )
                        )
                )

                // Hero content
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(24.dp),
                    verticalArrangement = Arrangement.Center,
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    // Stars
                    Text(
                        text = "⭐⭐⭐⭐⭐",
                        fontSize = 14.sp
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = Translation.get("welcome_title", lang),
                        fontSize = 28.sp,
                        fontWeight = FontWeight.Black,
                        color = LuxuryGold,
                        textAlign = TextAlign.Center,
                        lineHeight = 36.sp
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Text(
                        text = Translation.get("welcome_subtitle", lang),
                        fontSize = 14.sp,
                        color = LuxuryTextLight,
                        textAlign = TextAlign.Center,
                        lineHeight = 22.sp,
                        modifier = Modifier.padding(horizontal = 16.dp)
                    )

                    Spacer(modifier = Modifier.height(24.dp))

                    // Buttons Row
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        modifier = Modifier.fillMaxWidth(0.9f)
                    ) {
                        Button(
                            onClick = onBookNow,
                            modifier = Modifier
                                .weight(1f)
                                .height(50.dp)
                                .testTag("hero_book_now"),
                            colors = ButtonDefaults.buttonColors(containerColor = LuxuryGold),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text(
                                text = Translation.get("book_now", lang),
                                fontWeight = FontWeight.Bold,
                                color = LuxuryLightText,
                                fontSize = 14.sp
                            )
                        }

                        OutlinedButton(
                            onClick = onWatchVideo,
                            modifier = Modifier
                                .weight(1f)
                                .height(50.dp)
                                .testTag("hero_watch_video"),
                            border = BorderStroke(1.5.dp, LuxuryGold),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = LuxuryGold),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text(
                                text = Translation.get("watch_video", lang),
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )
                        }
                    }
                }
            }
        }

        // Search booking card (Overlapped widget design)
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp)
                    .offset(y = (-40).dp),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = LuxuryCardBg),
                elevation = CardDefaults.cardElevation(14.dp),
                border = BorderStroke(1.dp, LuxuryGold.copy(alpha = 0.5f))
            ) {
                Column(
                    modifier = Modifier.padding(20.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = "PLAN YOUR IMPERIAL STAY",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = LuxuryGold,
                        letterSpacing = 1.sp
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        // Check In
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = Translation.get("check_in", lang),
                                fontSize = 11.sp,
                                color = LuxuryTextMuted
                            )
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(LuxuryDarkGreen)
                                    .clickable { /* Simulate picking Date */ }
                                    .padding(10.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    Icons.Default.DateRange,
                                    contentDescription = null,
                                    tint = LuxuryGold,
                                    modifier = Modifier.size(14.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(checkIn, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                        }

                        // Check Out
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = Translation.get("check_out", lang),
                                fontSize = 11.sp,
                                color = LuxuryTextMuted
                            )
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(LuxuryDarkGreen)
                                    .clickable { /* Simulate picking Date */ }
                                    .padding(10.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    Icons.Default.DateRange,
                                    contentDescription = null,
                                    tint = LuxuryGold,
                                    modifier = Modifier.size(14.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(checkOut, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }

                    // Guests count
                    Column(modifier = Modifier.fillMaxWidth()) {
                        Text(
                            text = Translation.get("guests", lang),
                            fontSize = 11.sp,
                            color = LuxuryTextMuted
                        )
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .background(LuxuryDarkGreen)
                                .padding(horizontal = 12.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "$guestNum Adults Package",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                IconButton(
                                    onClick = { if (guestNum > 1) guestNum-- },
                                    modifier = Modifier.size(28.dp)
                                ) {
                                    Icon(Icons.Default.Remove, contentDescription = "Less", tint = LuxuryGold)
                                }
                                Text("$guestNum", fontSize = 14.sp, fontWeight = FontWeight.Black)
                                IconButton(
                                    onClick = { if (guestNum < 8) guestNum++ },
                                    modifier = Modifier.size(28.dp)
                                ) {
                                    Icon(Icons.Default.Add, contentDescription = "More", tint = LuxuryGold)
                                }
                            }
                        }
                    }

                    Button(
                        onClick = {
                            viewModel.checkInDate.value = checkIn
                            viewModel.checkOutDate.value = checkOut
                            viewModel.guestCount.value = guestNum
                            viewModel.navigateTo(HotelScreen.Rooms)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = LuxuryGold),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 4.dp)
                            .testTag("check_availability_btn")
                    ) {
                        Text(
                            text = Translation.get("check_availability", lang).uppercase(),
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = LuxuryLightText
                        )
                    }
                }
            }
        }

        // Room carousel slider preview teaser
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.Bottom
                ) {
                    Column {
                        Text(
                            text = "SANCTUARIES",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = LuxuryGold
                        )
                        Text(
                            text = "Imperial Rooms Highlight",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.ExtraBold
                        )
                    }
                    Text(
                        text = "View All →",
                        fontSize = 12.sp,
                        color = LuxuryGold,
                        modifier = Modifier
                            .clickable { viewModel.navigateTo(HotelScreen.Rooms) }
                            .padding(4.dp)
                    )
                }

                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    contentPadding = PaddingValues(vertical = 8.dp)
                ) {
                    items(viewModel.hotelRooms) { r ->
                        Card(
                            onClick = {
                                viewModel.navigateTo(HotelScreen.Rooms)
                            },
                            modifier = Modifier.width(280.dp),
                            colors = CardDefaults.cardColors(containerColor = LuxuryCardBg),
                            shape = RoundedCornerShape(14.dp)
                        ) {
                            Column {
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(150.dp)
                                ) {
                                    AsyncImage(
                                        model = ImageRequest.Builder(LocalContext.current)
                                            .data(r.imageUrl)
                                            .crossfade(true)
                                            .build(),
                                        contentDescription = r.id,
                                        contentScale = ContentScale.Crop,
                                        modifier = Modifier.fillMaxSize()
                                    )
                                    Box(
                                        modifier = Modifier
                                            .align(Alignment.TopEnd)
                                            .padding(10.dp)
                                            .clip(RoundedCornerShape(6.dp))
                                            .background(Color.Black.copy(alpha = 0.7f))
                                            .padding(horizontal = 6.dp, vertical = 2.dp)
                                    ) {
                                        Text(
                                            "⭐ ${r.rating}",
                                            fontSize = 11.sp,
                                            color = LuxuryGold,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                                Column(modifier = Modifier.padding(14.dp)) {
                                    Text(
                                        text = Translation.get(r.titleKey, lang),
                                        fontSize = 15.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Text(
                                        text = "USD ${r.price} / night",
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Black,
                                        color = LuxuryGold
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // About block quick introduction
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(24.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .background(LuxuryCardBg)
                    .border(1.dp, LuxuryPlaceholder, RoundedCornerShape(16.dp))
                    .padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "THE IMPERIAL LEGACY",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = LuxuryGold,
                    letterSpacing = 1.sp
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = Translation.get("about_title", lang),
                    fontSize = 20.sp,
                    fontWeight = FontWeight.ExtraBold,
                    textAlign = TextAlign.Center
                )
                Spacer(modifier = Modifier.height(12.dp))
                Text(
                    text = Translation.get("about_desc", lang),
                    fontSize = 13.sp,
                    color = LuxuryTextMuted,
                    textAlign = TextAlign.Center,
                    lineHeight = 20.sp
                )
                Spacer(modifier = Modifier.height(16.dp))
                Button(
                    onClick = { viewModel.navigateTo(HotelScreen.About) },
                    colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent),
                    border = BorderStroke(1.dp, LuxuryGold),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text("Read Our History", color = LuxuryGold, fontSize = 12.sp)
                }
            }
        }

        // Real-world dynamic Testimonials Slider Card
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(
                    text = "DIPLOMATIC ESSAYS",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = LuxuryGold
                )
                Text(
                    text = "Aesthetic Experiences",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.ExtraBold
                )

                ElevatedCard(
                    colors = CardDefaults.elevatedCardColors(containerColor = LuxuryCardBg),
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(20.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = "“Diredawa Ras Hotel remains a jewel of eastern Ethiopia. The hospitality captures royal warmth while matching global quality with incredible comfort!”",
                            fontSize = 13.sp,
                            fontStyle = FontStyle.Italic,
                            textAlign = TextAlign.Center,
                            color = LuxuryTextLight,
                            lineHeight = 22.sp
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(CircleShape)
                                    .background(LuxuryGold),
                                contentAlignment = Alignment.Center
                            ) {
                                Text("A", fontWeight = FontWeight.Bold, color = Color.Black)
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text(
                                    "Ambassador Alula",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    "Addis Ababa Diplomatic Corp",
                                    fontSize = 10.sp,
                                    color = LuxuryTextMuted
                                )
                            }
                        }
                    }
                }
            }
        }

        // Interactive Google Maps representation block
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(
                    text = "OUR LOCATION",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = LuxuryGold
                )
                Text(
                    text = "In the heart of Dire Dawa",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.ExtraBold
                )

                // Mock elegant graphical schematic Map representing the hotel local positioning
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(180.dp)
                        .clip(RoundedCornerShape(16.dp))
                        .background(Color(0xFF1E2822))
                        .border(1.dp, LuxuryPlaceholder, RoundedCornerShape(16.dp))
                ) {
                    // Geometric drawing layout mapping roads
                    Canvas(modifier = Modifier.fillMaxSize()) {
                        // Background road colors
                        val roadBrush = Brush.horizontalGradient(colors = listOf(Color(0xFF2A3A31), Color(0xFF233028)))
                        drawRect(color = Color(0xFF142017))
                        // Representing roads cross section inside Dire Dawa
                        drawLine(color = Color(0xFF32493C), start = androidx.compose.ui.geometry.Offset(0f, 150f), end = androidx.compose.ui.geometry.Offset(size.width, 150f), strokeWidth = 14f)
                        drawLine(color = Color(0xFF32493C), start = androidx.compose.ui.geometry.Offset(200f, 0f), end = androidx.compose.ui.geometry.Offset(200f, size.height), strokeWidth = 14f)
                    }

                    // Centred Hotel PIN Pointer
                    Column(
                        modifier = Modifier.align(Alignment.Center),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            imageVector = Icons.Default.LocationOn,
                            contentDescription = null,
                            tint = LuxuryGold,
                            modifier = Modifier.size(36.dp)
                        )
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(4.dp))
                                .background(Color.Black)
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(
                                "DIREDAWA RAS HOTEL",
                                fontSize = 9.sp,
                                color = LuxuryGold,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }

        // Royal Footer
        item {
            RoyalFooter(lang = lang)
        }
    }
}

// -------------------------------------------------------------
// 2. ABOUT US SECTION
// -------------------------------------------------------------
@Composable
fun AboutSection(lang: AppLanguage) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(24.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text(
                text = "ABOUT US",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = LuxuryGold,
                letterSpacing = 2.sp
            )
            Text(
                text = Translation.get("about_title", lang),
                fontSize = 26.sp,
                fontWeight = FontWeight.Black
            )
        }

        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = LuxuryCardBg),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Text(
                        text = Translation.get("about_desc", lang),
                        fontSize = 14.sp,
                        color = LuxuryTextLight,
                        lineHeight = 22.sp
                    )
                }
            }
        }

        item {
            Text(
                text = "Imperial Heritage Elements",
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                color = LuxuryGold
            )
        }

        item {
            AboutMilestoneRow(
                year = "1968",
                title = "Inaugural Ribbon Cut",
                desc = "Commissioned under imperial patronage during the high railway connection boom."
            )
        }

        item {
            AboutMilestoneRow(
                year = "1980",
                title = "Diplomatic Nexus",
                desc = "Hosted major East African trade delegates, setting legacy hospitality marks."
            )
        }

        item {
            AboutMilestoneRow(
                year = "2026",
                title = "Cinema Modern Renovation",
                desc = "Redefined with interactive glassmorphism components & environmental solar frameworks."
            )
        }

        item {
            Spacer(modifier = Modifier.height(40.dp))
            RoyalFooter(lang = lang)
        }
    }
}

@Composable
fun AboutMilestoneRow(year: String, title: String, desc: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(LuxuryCardBg.copy(alpha = 0.5f))
            .padding(16.dp),
        verticalAlignment = Alignment.Top
    ) {
        Box(
            modifier = Modifier
                .clip(RoundedCornerShape(6.dp))
                .background(LuxuryGold)
                .padding(horizontal = 10.dp, vertical = 6.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(year, fontWeight = FontWeight.Bold, color = Color.Black, fontSize = 14.sp)
        }
        Spacer(modifier = Modifier.width(16.dp))
        Column {
            Text(title, fontWeight = FontWeight.Bold, fontSize = 14.sp, color = LuxuryGold)
            Spacer(modifier = Modifier.height(2.dp))
            Text(desc, fontSize = 12.sp, color = LuxuryTextMuted)
        }
    }
}

// -------------------------------------------------------------
// 3. ROOMS SECTION
// -------------------------------------------------------------
@Composable
fun RoomsSection(
    viewModel: HotelViewModel,
    lang: AppLanguage,
    favorites: List<FavoriteEntity>,
    onBookNow: (room: HotelRoom) -> Unit
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text(
                text = Translation.get("rooms_title", lang).uppercase(),
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = LuxuryGold,
                letterSpacing = 2.sp
            )
            Text(
                text = Translation.get("rooms_subtitle", lang),
                fontSize = 15.sp,
                color = LuxuryTextMuted
            )
        }

        items(viewModel.hotelRooms) { r ->
            val isFav = favorites.any { it.roomName == r.titleKey && it.isFavorite }
            
            Card(
                colors = CardDefaults.cardColors(containerColor = LuxuryCardBg),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("room_card_${r.id}"),
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, LuxuryPlaceholder)
            ) {
                Column {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(180.dp)
                    ) {
                        // Coil Image loading
                        AsyncImage(
                            model = ImageRequest.Builder(LocalContext.current)
                                .data(r.imageUrl)
                                .crossfade(true)
                                .build(),
                            contentDescription = r.id,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize()
                        )

                        // Top Heart favorite selector toggle
                        IconButton(
                            onClick = { viewModel.toggleFavorite(r.titleKey) },
                            modifier = Modifier
                                .align(Alignment.TopEnd)
                                .padding(12.dp)
                                .background(Color.Black.copy(alpha = 0.6f), CircleShape)
                                .testTag("fav_btn_${r.id}")
                        ) {
                            Icon(
                                imageVector = if (isFav) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                                contentDescription = "Favorite",
                                tint = if (isFav) Color.Red else Color.White,
                                modifier = Modifier.size(20.dp)
                            )
                        }

                        // Rating overlay
                        Box(
                            modifier = Modifier
                                .align(Alignment.BottomStart)
                                .padding(12.dp)
                                .clip(RoundedCornerShape(4.dp))
                                .background(Color.Black.copy(alpha = 0.7f))
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text("⭐ ${r.rating}", color = LuxuryGold, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    Column(modifier = Modifier.padding(18.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = Translation.get(r.titleKey, lang),
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold,
                                color = LuxuryGold
                            )
                            Text(
                                text = Translation.get("price_per_night", lang).format(r.price.toInt()),
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Black
                            )
                        }

                        Spacer(modifier = Modifier.height(6.dp))

                        // Features row
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            RoomSpecTag(icon = Icons.Default.AspectRatio, value = r.size)
                            RoomSpecTag(icon = Icons.Default.People, value = r.capacity)
                            RoomSpecTag(icon = Icons.Default.KingBed, value = r.bedType.take(12) + "..")
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        Text(
                            text = Translation.get(r.descKey, lang),
                            fontSize = 12.sp,
                            color = LuxuryTextMuted,
                            lineHeight = 18.sp
                        )

                        Spacer(modifier = Modifier.height(16.dp))

                        Button(
                            onClick = { onBookNow(r) },
                            colors = ButtonDefaults.buttonColors(containerColor = LuxuryGold),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("book_btn_${r.id}"),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Text(
                                text = Translation.get("book_now", lang),
                                fontWeight = FontWeight.Bold,
                                color = LuxuryLightText
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun RoomSpecTag(icon: ImageVector, value: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(imageVector = icon, contentDescription = null, tint = LuxuryGold, modifier = Modifier.size(13.dp))
        Spacer(modifier = Modifier.width(4.dp))
        Text(text = value, fontSize = 10.sp, color = LuxuryTextLight, fontWeight = FontWeight.Medium)
    }
}

// -------------------------------------------------------------
// 4. SERVICES SECTION
// -------------------------------------------------------------
@Composable
fun ServicesSection(lang: AppLanguage) {
    val listServices = listOf(
        Triple("fine_dining", Icons.Default.Restaurant, "fine_dining"),
        Triple("free_wifi", Icons.Default.Wifi, "free_wifi"),
        Triple("meeting_hall", Icons.Default.CorporateFare, "meeting_hall"),
        Triple("airport_pickup", Icons.Default.AirportShuttle, "airport_pickup"),
        Triple("gym_spa", Icons.Default.Spa, "gym_spa"),
        Triple("service_247", Icons.Default.AccessTime, "service_247")
    )

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text(
                text = Translation.get("services_title", lang).uppercase(),
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = LuxuryGold,
                letterSpacing = 2.sp
            )
            Text(
                text = Translation.get("services_desc", lang),
                fontSize = 14.sp,
                color = LuxuryTextMuted
            )
        }

        item {
            // Render 3x2 services inside custom responsive cards
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                for (i in listServices.indices step 2) {
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        ServiceCard(
                            label = Translation.get(listServices[i].first, lang),
                            icon = listServices[i].second,
                            modifier = Modifier.weight(1f)
                        )
                        if (i + 1 < listServices.size) {
                            ServiceCard(
                                label = Translation.get(listServices[i + 1].first, lang),
                                icon = listServices[i + 1].second,
                                modifier = Modifier.weight(1f)
                            )
                        } else {
                            Spacer(modifier = Modifier.weight(1f))
                        }
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(24.dp))
            RoyalFooter(lang = lang)
        }
    }
}

@Composable
fun ServiceCard(label: String, icon: ImageVector, modifier: Modifier = Modifier) {
    Card(
        modifier = modifier.height(110.dp),
        colors = CardDefaults.cardColors(containerColor = LuxuryCardBg),
        border = BorderStroke(1.dp, LuxuryPlaceholder)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(14.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = LuxuryGold,
                modifier = Modifier.size(32.dp)
            )
            Spacer(modifier = Modifier.height(10.dp))
            Text(
                text = label,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center,
                color = Color.White,
                maxLines = 2
            )
        }
    }
}

// -------------------------------------------------------------
// 5. GALLERY SECTION
// -------------------------------------------------------------
@Composable
fun GallerySection(lang: AppLanguage) {
    val picUrls = listOf(
        "https://images.unsplash.com/photo-1542314831-068cd1dbfeeb?auto=format&fit=crop&w=600&q=80",
        "https://images.unsplash.com/photo-1571896349842-33c89424de2d?auto=format&fit=crop&w=600&q=80",
        "https://images.unsplash.com/photo-1445019980597-93fa8acb246c?auto=format&fit=crop&w=600&q=80",
        "https://images.unsplash.com/photo-1551882547-ff40c63fe5fa?auto=format&fit=crop&w=600&q=80",
        "https://images.unsplash.com/photo-1584132967334-10e028bd69f7?auto=format&fit=crop&w=600&q=80",
        "https://images.unsplash.com/photo-1520250497591-112f2f40a3f4?auto=format&fit=crop&w=600&q=80"
    )

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text(
                text = Translation.get("gallery", lang).uppercase(),
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = LuxuryGold,
                letterSpacing = 2.sp
            )
        }

        items(picUrls.chunked(2)) { pair ->
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .height(140.dp)
                        .clip(RoundedCornerShape(12.dp))
                ) {
                    AsyncImage(
                        model = picUrls[0],
                        contentDescription = null,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                }
                if (pair.size > 1) {
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .height(140.dp)
                            .clip(RoundedCornerShape(12.dp))
                    ) {
                        AsyncImage(
                            model = pair[1],
                            contentDescription = null,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize()
                        )
                    }
                }
            }
        }

        item {
            RoyalFooter(lang = lang)
        }
    }
}

// -------------------------------------------------------------
// 6. RESTAURANT & DINING
// -------------------------------------------------------------
@Composable
fun DiningSection(lang: AppLanguage) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text(
                text = Translation.get("dining_section", lang).uppercase(),
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = LuxuryGold,
                letterSpacing = 2.sp
            )
            Text(
                text = Translation.get("dining_desc", lang),
                fontSize = 14.sp,
                lineHeight = 22.sp,
                color = LuxuryTextMuted
            )
        }

        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(200.dp)
                    .clip(RoundedCornerShape(16.dp))
            ) {
                AsyncImage(
                    model = "https://images.unsplash.com/photo-1544025162-d76694265947?auto=format&fit=crop&w=800&q=80",
                    contentDescription = "Dining Setup",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
            }
        }

        item {
            Text(
                text = "Harrar Artisan Roast Corner",
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                color = LuxuryGold
            )
            Text(
                text = "Enjoy the richest local coffee directly from the eastern Ethiopian roots, roasted daily at our bespoke lobby roaster.",
                fontSize = 12.sp,
                color = LuxuryTextLight,
                lineHeight = 18.sp
            )
        }

        item {
            RoyalFooter(lang = lang)
        }
    }
}

// -------------------------------------------------------------
// 7. EVENTS & MEETINGS
// -------------------------------------------------------------
@Composable
fun EventsSection(lang: AppLanguage) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text(
                text = Translation.get("events_meetings", lang).uppercase(),
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = LuxuryGold
            )
            Text(
                text = Translation.get("events_desc", lang),
                fontSize = 14.sp,
                lineHeight = 22.sp,
                color = LuxuryTextMuted
            )
        }

        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(200.dp)
                    .clip(RoundedCornerShape(16.dp))
            ) {
                AsyncImage(
                    model = "https://images.unsplash.com/photo-1511578314322-379afb476865?auto=format&fit=crop&w=800&q=80",
                    contentDescription = "Conference hall logo",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
            }
        }

        item {
            RoyalFooter(lang = lang)
        }
    }
}

// -------------------------------------------------------------
// 8. OFFERS SECTION
// -------------------------------------------------------------
@Composable
fun OffersSection(lang: AppLanguage) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text(
                text = Translation.get("offers", lang).uppercase(),
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = LuxuryGold
            )
            Text(
                text = Translation.get("offers_desc", lang),
                fontSize = 14.sp,
                color = LuxuryTextMuted
            )
        }

        item {
            OfferItemCard(
                title = "Dire Dawa Local Getaway Package",
                discount = "25% OFF",
                description = "Includes free private airport pick-up and complete guided tours of the historical railway terminal."
            )
        }

        item {
            OfferItemCard(
                title = "Honeymoon Imperial Special",
                discount = "FREE SPA WORK",
                description = "Relax inside our newly solar-heated therapeutic pool and get champagne on arrival."
            )
        }

        item {
            RoyalFooter(lang = lang)
        }
    }
}

@Composable
fun OfferItemCard(title: String, discount: String, description: String) {
    Card(
        colors = CardDefaults.cardColors(containerColor = LuxuryCardBg),
        border = BorderStroke(1.dp, LuxuryPlaceholder),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            horizontalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .background(LuxuryGold)
                    .padding(10.dp)
            ) {
                Text(discount, color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 11.sp)
            }
            Column {
                Text(title, fontWeight = FontWeight.Bold, fontSize = 14.sp, color = LuxuryGold)
                Spacer(modifier = Modifier.height(2.dp))
                Text(description, fontSize = 12.sp, color = LuxuryTextLight, lineHeight = 18.sp)
            }
        }
    }
}

// -------------------------------------------------------------
// 9. BOOKING FORM SECTION
// -------------------------------------------------------------
@Composable
fun BookingSection(
    viewModel: HotelViewModel,
    lang: AppLanguage,
    onTriggerPayment: (room: HotelRoom) -> Unit
) {
    var checkIn by remember { mutableStateOf("2026-05-27") }
    var checkOut by remember { mutableStateOf("2026-05-30") }
    var selectGuests by remember { mutableStateOf(1) }
    var selRoomIndex by remember { mutableStateOf(0) }

    val nights = viewModel.calculateNights(checkIn, checkOut)
    val room = viewModel.hotelRooms[selRoomIndex]
    val subtotal = room.price * nights

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Text(
                text = "SECURE RESERVATION ENGINE",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = LuxuryGold
            )
            Text(
                text = "Imperial Booking Schedule",
                fontSize = 20.sp,
                fontWeight = FontWeight.Black
            )
        }

        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = LuxuryCardBg),
                modifier = Modifier.fillMaxWidth(),
                border = BorderStroke(1.dp, LuxuryPlaceholder)
            ) {
                Column(
                    modifier = Modifier.padding(18.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    // Pick Room Dropdown
                    Column {
                        Text("SELECT SANCTUARY CATEGORY", fontSize = 11.sp, color = LuxuryGold, fontWeight = FontWeight.Bold)
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .background(LuxuryDarkGreen)
                                .clickable {
                                    selRoomIndex = (selRoomIndex + 1) % viewModel.hotelRooms.size
                                }
                                .padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = Translation.get(room.titleKey, lang),
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Icon(Icons.Default.ArrowForward, contentDescription = null, tint = LuxuryGold, modifier = Modifier.size(16.dp))
                        }
                    }

                    // Schedule Dates Row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(Translation.get("check_in", lang).uppercase(), fontSize = 10.sp, color = LuxuryTextMuted)
                            OutlinedTextField(
                                value = checkIn,
                                onValueChange = { checkIn = it },
                                modifier = Modifier.fillMaxWidth(),
                                textStyle = TextStyle(fontSize = 12.sp, color = Color.White),
                                singleLine = true
                            )
                        }
                        Column(modifier = Modifier.weight(1f)) {
                            Text(Translation.get("check_out", lang).uppercase(), fontSize = 10.sp, color = LuxuryTextMuted)
                            OutlinedTextField(
                                value = checkOut,
                                onValueChange = { checkOut = it },
                                modifier = Modifier.fillMaxWidth(),
                                textStyle = TextStyle(fontSize = 12.sp, color = Color.White),
                                singleLine = true
                            )
                        }
                    }

                    // Guests Slider/selector
                    Column {
                        Text("GUEST ASSIGNMENT", fontSize = 11.sp, color = LuxuryGold, fontWeight = FontWeight.Bold)
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("$selectGuests Adults Package", fontSize = 12.sp)
                            Row {
                                IconButton(onClick = { if (selectGuests > 1) selectGuests-- }) {
                                    Icon(Icons.Default.Remove, contentDescription = null, tint = LuxuryGold)
                                }
                                Text(
                                    "$selectGuests",
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(top = 10.dp)
                                )
                                IconButton(onClick = { if (selectGuests < 10) selectGuests++ }) {
                                    Icon(Icons.Default.Add, contentDescription = null, tint = LuxuryGold)
                                }
                            }
                        }
                    }

                    Divider(color = LuxuryPlaceholder, thickness = 1.dp)

                    // Calculated Subtotal Layout
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text("Stay Duration", fontSize = 11.sp, color = LuxuryTextMuted)
                            Text("$nights Nights", fontSize = 13.sp, fontWeight = FontWeight.Black)
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text("Estimated Price", fontSize = 11.sp, color = LuxuryTextMuted)
                            Text("USD $subtotal", fontSize = 16.sp, fontWeight = FontWeight.Black, color = LuxuryGold)
                        }
                    }

                    // Booking Action CTA
                    Button(
                        onClick = {
                            viewModel.checkInDate.value = checkIn
                            viewModel.checkOutDate.value = checkOut
                            viewModel.guestCount.value = selectGuests
                            onTriggerPayment(room)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = LuxuryGold),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 8.dp)
                            .testTag("proc_payment_btn"),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text(
                            text = Translation.get("book_now", lang).uppercase(),
                            fontWeight = FontWeight.Bold,
                            color = LuxuryLightText
                        )
                    }
                }
            }
        }
        item {
            RoyalFooter(lang = lang)
        }
    }
}

// -------------------------------------------------------------
// 10. CONTACT SECTION
// -------------------------------------------------------------
@Composable
fun ContactSection(lang: AppLanguage) {
    var senderEmail by remember { mutableStateOf("") }
    var senderMessage by remember { mutableStateOf("") }
    val context = LocalContext.current

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text(
                text = "CONCIERGE & SUPPORT",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = LuxuryGold
            )
            Text(
                text = Translation.get("contact_title", lang),
                fontSize = 20.sp,
                fontWeight = FontWeight.Black
            )
        }

        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = LuxuryCardBg),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(18.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = "Query Desk Form",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = LuxuryGold
                    )

                    OutlinedTextField(
                        value = senderEmail,
                        onValueChange = { senderEmail = it },
                        label = { Text("Your Email") },
                        modifier = Modifier.fillMaxWidth(),
                        textStyle = TextStyle(color = Color.White)
                    )

                    OutlinedTextField(
                        value = senderMessage,
                        onValueChange = { senderMessage = it },
                        label = { Text("How can we assist you?") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(110.dp),
                        textStyle = TextStyle(color = Color.White)
                    )

                    Button(
                        onClick = {
                            if (senderEmail.isNotEmpty() && senderMessage.isNotEmpty()) {
                                Toast.makeText(context, "Message delivered to the butler team!", Toast.LENGTH_LONG).show()
                                senderEmail = ""
                                senderMessage = ""
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = LuxuryGold),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Send Dispatch", color = Color.Black, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        item {
            RoyalFooter(lang = lang)
        }
    }
}

// -------------------------------------------------------------
// 11. AUTHENTICATION SECTION (Login & Signup)
// -------------------------------------------------------------
@Composable
fun AuthSection(viewModel: HotelViewModel, lang: AppLanguage) {
    val email by viewModel.emailInput.collectAsStateWithLifecycle()
    val password by viewModel.passwordInput.collectAsStateWithLifecycle()
    val isOtpState by viewModel.isOtpState.collectAsStateWithLifecycle()
    val otpInput by viewModel.otpInput.collectAsStateWithLifecycle()
    val error by viewModel.authError.collectAsStateWithLifecycle()
    val success by viewModel.authSuccessMsg.collectAsStateWithLifecycle()

    var isLoginMode by remember { mutableStateOf(true) }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        item {
            Text(
                text = "⚜️",
                fontSize = 32.sp
            )
            Spacer(modifier = Modifier.height(10.dp))
            Text(
                text = if (isOtpState) {
                    Translation.get("otp_code", lang)
                } else if (isLoginMode) {
                    Translation.get("login_signup", lang)
                } else {
                    Translation.get("signup", lang)
                },
                fontSize = 22.sp,
                fontWeight = FontWeight.Black,
                color = LuxuryGold
            )
            Spacer(modifier = Modifier.height(20.dp))
        }

        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = LuxuryCardBg),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("auth_card"),
                border = BorderStroke(1.dp, LuxuryGold.copy(alpha = 0.5f))
            ) {
                Column(
                    modifier = Modifier.padding(20.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    
                    if (!isOtpState) {
                        // Email field
                        OutlinedTextField(
                            value = email,
                            onValueChange = { viewModel.emailInput.value = it },
                            label = { Text(Translation.get("email", lang)) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("email_field"),
                            textStyle = TextStyle(color = Color.White),
                            singleLine = true
                        )

                        // Password field
                        OutlinedTextField(
                            value = password,
                            onValueChange = { viewModel.passwordInput.value = it },
                            label = { Text(Translation.get("password", lang)) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("password_field"),
                            textStyle = TextStyle(color = Color.White),
                            visualTransformation = PasswordVisualTransformation(),
                            singleLine = true
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        // Submit action
                        Button(
                            onClick = {
                                if (isLoginMode) viewModel.login() else viewModel.signup()
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = LuxuryGold),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("auth_submit_btn")
                        ) {
                            Text(
                                text = if (isLoginMode) {
                                    Translation.get("btn_login", lang)
                                } else {
                                    "Dispatch OTP"
                                },
                                fontWeight = FontWeight.Bold,
                                color = LuxuryLightText
                            )
                        }

                        // Switch mode button
                        TextButton(
                            onClick = { isLoginMode = !isLoginMode },
                            colors = ButtonDefaults.textButtonColors(contentColor = LuxuryGold),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = if (isLoginMode) {
                                    "No imperial credentials? Register here"
                                } else {
                                    "Access existing executive account"
                                },
                                fontSize = 12.sp,
                                textAlign = TextAlign.Center
                            )
                        }
                    } else {
                        // OTP VERIFICATION STATE
                        Text(
                            text = Translation.get("otp_desc", lang),
                            fontSize = 12.sp,
                            color = LuxuryTextLight,
                            textAlign = TextAlign.Center
                        )

                        OutlinedTextField(
                            value = otpInput,
                            onValueChange = { viewModel.otpInput.value = it },
                            label = { Text(Translation.get("otp_code", lang)) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("otp_field"),
                            textStyle = TextStyle(color = Color.White),
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            singleLine = true
                        )

                        Button(
                            onClick = { viewModel.verifyOtp() },
                            colors = ButtonDefaults.buttonColors(containerColor = LuxuryGold),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("otp_submit_btn")
                        ) {
                            Text(
                                text = Translation.get("btn_signup", lang),
                                fontWeight = FontWeight.Bold,
                                color = LuxuryLightText
                            )
                        }
                    }

                    // Alerts
                    error?.let { err ->
                        Text(
                            text = err,
                            color = Color.Red,
                            fontSize = 11.sp,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.fillMaxWidth().testTag("auth_error")
                        )
                    }

                    success?.let { ok ->
                        Text(
                            text = ok,
                            color = LuxuryGold,
                            fontSize = 11.sp,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.fillMaxWidth().testTag("auth_success")
                        )
                    }
                }
            }
        }
    }
}

// -------------------------------------------------------------
// 12. USER EXECUTIVE DASHBOARD SECTION
// -------------------------------------------------------------
@Composable
fun DashboardSection(
    viewModel: HotelViewModel,
    lang: AppLanguage,
    favorites: List<FavoriteEntity>,
    onBookNow: (room: HotelRoom) -> Unit
) {
    val currentUser by viewModel.currentUser.collectAsStateWithLifecycle()
    val bookings by viewModel.allBookings.collectAsStateWithLifecycle()

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text(
                text = Translation.get("user_dashboard", lang).uppercase(),
                fontSize = 12.sp,
                color = LuxuryGold,
                fontWeight = FontWeight.Bold,
                letterSpacing = 2.sp
            )
            Text(
                text = "${Translation.get("welcome_guest", lang)}: ${currentUser?.email ?: "Guest Traveler"}",
                fontSize = 16.sp,
                fontWeight = FontWeight.ExtraBold
            )
        }

        item {
            // General Metrics layout overview card
            Card(
                colors = CardDefaults.cardColors(containerColor = LuxuryCardBg),
                modifier = Modifier.fillMaxWidth(),
                border = BorderStroke(1.dp, LuxuryPlaceholder)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceAround
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("Active Bookings", fontSize = 11.sp, color = LuxuryTextMuted)
                        Text("${bookings.size}", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = LuxuryGold)
                    }
                    Divider(modifier = Modifier.height(30.dp).width(1.dp), color = LuxuryPlaceholder)
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("Saved Sanct.", fontSize = 11.sp, color = LuxuryTextMuted)
                        Text("${favorites.size}", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = LuxuryGold)
                    }
                    Divider(modifier = Modifier.height(30.dp).width(1.dp), color = LuxuryPlaceholder)
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("Tier Status", fontSize = 11.sp, color = LuxuryTextMuted)
                        Text("Gold Executive", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = LuxuryGold)
                    }
                }
            }
        }

        // Saved favorite rooms in real-time
        item {
            Text(
                text = "SAVED SANCTUARIES",
                fontSize = 12.sp,
                color = LuxuryGold,
                fontWeight = FontWeight.Bold
            )
        }

        if (favorites.isEmpty()) {
            item {
                Text(
                    Translation.get("no_favorites", lang),
                    fontSize = 12.sp,
                    color = LuxuryTextMuted,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        } else {
            items(favorites) { f ->
                val matchedRoom = viewModel.hotelRooms.find { it.titleKey == f.roomName }
                matchedRoom?.let { r ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(LuxuryCardBg)
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(64.dp)
                                .clip(RoundedCornerShape(8.dp))
                        ) {
                            AsyncImage(
                                model = r.imageUrl,
                                contentDescription = null,
                                contentScale = ContentScale.Crop,
                                modifier = Modifier.fillMaxSize()
                            )
                        }
                        Spacer(modifier = Modifier.width(16.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(Translation.get(r.titleKey, lang), fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            Text("USD ${r.price} / night", fontSize = 11.sp, color = LuxuryGold)
                        }
                        Button(
                            onClick = { onBookNow(r) },
                            colors = ButtonDefaults.buttonColors(containerColor = LuxuryGold),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Text("Book", fontSize = 11.sp, color = Color.Black, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        // Room Database list of reservations history
        item {
            Text(
                text = Translation.get("bookings_history", lang).uppercase(),
                fontSize = 12.sp,
                color = LuxuryGold,
                fontWeight = FontWeight.Bold
            )
        }

        if (bookings.isEmpty()) {
            item {
                Text(
                    Translation.get("no_bookings", lang),
                    fontSize = 12.sp,
                    color = LuxuryTextMuted,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        } else {
            items(bookings) { b ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = LuxuryCardBg.copy(alpha = 0.6f)),
                    border = BorderStroke(1.dp, LuxuryPlaceholder)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = Translation.get(b.roomName, lang),
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp,
                                color = LuxuryGold
                            )
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(Color(0xFF007500))
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text(b.status.uppercase(), fontSize = 9.sp, fontWeight = FontWeight.Black, color = Color.White)
                            }
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Dates: ${b.checkIn} to ${b.checkOut} (${b.guests} Guests)",
                            fontSize = 11.sp,
                            color = LuxuryTextMuted
                        )
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top = 8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Paid via: ${b.paymentMethod}",
                                fontSize = 11.sp,
                                color = LuxuryTextLight
                            )
                            Text(
                                text = "Total: USD ${b.totalPrice.toInt()}",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Black,
                                color = LuxuryGold
                            )
                        }
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(24.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // Clear bookings history button
                Button(
                    onClick = { viewModel.clearBookings() },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF6B0F0F)),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Text("Clear Histories", fontSize = 12.sp)
                }

                // Signout CTA
                Button(
                    onClick = { viewModel.logout() },
                    colors = ButtonDefaults.buttonColors(containerColor = LuxuryPlaceholder),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Text(Translation.get("logout", lang), fontSize = 12.sp)
                }
            }
        }

        item {
            RoyalFooter(lang = lang)
        }
    }
}

// -------------------------------------------------------------
// ROYAL ESTABLISHED FOOTER (Dynamic 12px signature requirement)
// -------------------------------------------------------------
@Composable
fun RoyalFooter(lang: AppLanguage) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Divider(color = LuxuryPlaceholder.copy(alpha = 0.5f), thickness = 1.dp)
        Spacer(modifier = Modifier.height(6.dp))

        Text(
            text = Translation.get("copyright", lang),
            fontSize = 12.sp,
            color = LuxuryTextMuted,
            textAlign = TextAlign.Center
        )

        Row(
            horizontalArrangement = Arrangement.spacedBy(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(Translation.get("address", lang), fontSize = 11.sp, color = LuxuryTextMuted)
            Text("•", fontSize = 11.sp, color = LuxuryGold)
            Text(Translation.get("phone", lang), fontSize = 11.sp, color = LuxuryTextMuted)
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Required 12px Center bottom elements
        Text(
            text = Translation.get("created_by", lang),
            fontSize = 12.sp,
            fontWeight = FontWeight.ExtraBold,
            color = LuxuryGold
        )
        Text(
            text = Translation.get("date_format", lang),
            fontSize = 12.sp,
            fontWeight = FontWeight.Medium,
            color = LuxuryTextMuted
        )
    }
}
