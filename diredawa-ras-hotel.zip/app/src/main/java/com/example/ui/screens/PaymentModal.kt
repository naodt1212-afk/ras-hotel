package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Payment
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material3.*
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.ui.theme.*
import com.example.ui.translation.AppLanguage
import com.example.ui.translation.Translation
import com.example.ui.viewmodel.HotelRoom

@Composable
fun PaymentModal(
    room: HotelRoom,
    lang: AppLanguage,
    onDismiss: () -> Unit,
    onPaymentConfirmed: (method: String) -> Unit
) {
    var selectedTab by remember { mutableStateOf(0) } // 0 = Local, 1 = International
    var snackbarMessage by remember { mutableStateOf<String?>(null) }

    val localBanks = listOf(
        "Telebirr" to "telebirr",
        "M-Pesa" to "mpesa",
        "CBE" to "cbe",
        "Awash Bank" to "awash",
        "Dashen Bank" to "dashen",
        "Abyssinia Bank" to "abyssinia",
        "Wegagen Bank" to "wegagen",
        "Amole" to "amole"
    )

    val intlGateways = listOf(
        "Visa" to "visa",
        "Mastercard" to "mastercard",
        "PayPal" to "paypal",
        "Stripe" to "stripe",
        "Apple Pay" to "applepay",
        "Google Pay" to "googlepay"
    )

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 16.dp),
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.surface
            ),
            shape = RoundedCornerShape(24.dp),
            elevation = CardDefaults.cardElevation(24.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(24.dp)
            ) {
                // Header with Close
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Lock,
                            contentDescription = null,
                            tint = LuxuryGold,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = Translation.get("payment_title", lang),
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold,
                            color = LuxuryGold
                        )
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Close Dialog",
                            tint = MaterialTheme.colorScheme.onSurface
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Room summary
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.2f))
                        .padding(14.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = Translation.get(room.titleKey, lang),
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "Rate: USD ${room.price} / night",
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                            )
                        }
                        Text(
                            text = "Room ID: ${room.id.uppercase()}",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = LuxuryGold,
                            modifier = Modifier
                                .border(1.dp, LuxuryGold, RoundedCornerShape(4.dp))
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Selector tabs
                TabRow(
                    selectedTabIndex = selectedTab,
                    containerColor = Color.Transparent,
                    contentColor = LuxuryGold,
                    indicator = { tabPositions ->
                        TabRowDefaults.SecondaryIndicator(
                            modifier = Modifier.tabIndicatorOffset(tabPositions[selectedTab]),
                            color = LuxuryGold
                        )
                    }
                ) {
                    Tab(
                        selected = selectedTab == 0,
                        onClick = { selectedTab = 0 },
                        text = {
                            Text(
                                text = Translation.get("local_payment", lang),
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    )
                    Tab(
                        selected = selectedTab == 1,
                        onClick = { selectedTab = 1 },
                        text = {
                            Text(
                                text = Translation.get("intl_payment", lang),
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Details list
                Box(
                    modifier = Modifier
                        .weight(1f, fill = false)
                        .heightIn(max = 240.dp)
                ) {
                    Column(
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        val currentList = if (selectedTab == 0) localBanks else intlGateways
                        
                        // Render grid
                        for (i in currentList.indices step 2) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                PaymentOptionCard(
                                    name = currentList[i].first,
                                    logoKey = currentList[i].second,
                                    modifier = Modifier.weight(1f),
                                    onClick = {
                                        snackbarMessage = Translation.get("bank_message", lang)
                                    }
                                )
                                if (i + 1 < currentList.size) {
                                    PaymentOptionCard(
                                        name = currentList[i + 1].first,
                                        logoKey = currentList[i + 1].second,
                                        modifier = Modifier.weight(1f),
                                        onClick = {
                                            snackbarMessage = Translation.get("bank_message", lang)
                                        }
                                    )
                                } else {
                                    Spacer(modifier = Modifier.weight(1f))
                                }
                            }
                        }
                    }
                }

                // Temporary Message Display
                AnimatedVisibility(
                    visible = snackbarMessage != null,
                    enter = fadeIn() + expandVertically(),
                    exit = fadeOut() + shrinkVertically()
                ) {
                    snackbarMessage?.let { msg ->
                        Spacer(modifier = Modifier.height(12.dp))
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .background(Color(0xFF8B0000).copy(alpha = 0.2f))
                                .border(1.dp, Color(0xFFFF4D4D), RoundedCornerShape(8.dp))
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.Info,
                                contentDescription = null,
                                tint = Color(0xFFFF4D4D),
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = msg,
                                fontSize = 12.sp,
                                color = Color(0xFFFF9999),
                                fontWeight = FontWeight.Medium
                            )
                            Spacer(modifier = Modifier.weight(1f))
                            Text(
                                text = "Dismiss",
                                fontSize = 11.sp,
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier
                                    .clickable { snackbarMessage = null }
                                    .padding(4.dp)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))

                // Bottom CTA action to book with offline guarantee
                Button(
                    onClick = {
                        // Confirms selection utilizing offline setup
                        onPaymentConfirmed("Offline Imperial Promise")
                    },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = LuxuryGold),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Payment,
                            contentDescription = null,
                            tint = LuxuryLightText
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = Translation.get("confirm_booking", lang),
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = LuxuryLightText
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun PaymentOptionCard(
    name: String,
    logoKey: String,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Surface(
        onClick = onClick,
        modifier = modifier
            .height(52.dp),
        shape = RoundedCornerShape(12.dp),
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f))
    ) {
        Row(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 12.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            // Simulated Logo inside Canvas drawing or custom box to prevent missing images
            Box(
                modifier = Modifier
                    .size(32.dp)
                    .clip(RoundedCornerShape(6.dp))
                    .background(
                        when (logoKey) {
                            "telebirr" -> Color(0xFF005DA6)
                            "mpesa" -> Color(0xFF4EB848)
                            "cbe" -> Color(0xFF4A148C)
                            "awash" -> Color(0xFF003366)
                            "dashen" -> Color(0xFFCE1126)
                            "abyssinia" -> Color(0xFFE5A823)
                            "wegagen" -> Color(0xFFAD1457)
                            "amole" -> Color(0xFFF57C00)
                            "visa" -> Color(0xFF1A1F71)
                            "mastercard" -> Color(0xFFEB001B)
                            "paypal" -> Color(0xFF003087)
                            "stripe" -> Color(0xFF635BFF)
                            "applepay" -> Color.Black
                            "googlepay" -> Color(0xFF4285F4)
                            else -> LuxuryGold
                        }
                    ),
                contentAlignment = Alignment.Center
            ) {
                // First initials
                Text(
                    text = name.take(2).uppercase(),
                    color = Color.White,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.ExtraBold
                )
            }

            Text(
                text = name,
                fontSize = 12.sp,
                fontWeight = FontWeight.SemiBold,
                maxLines = 1,
                color = MaterialTheme.colorScheme.onSurface
            )
        }
    }
}
