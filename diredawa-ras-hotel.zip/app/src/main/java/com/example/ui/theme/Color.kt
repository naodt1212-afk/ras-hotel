package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Premium Luxury Color Palette
val LuxuryDarkGreen = Color(0xFF0F2B1C)         // Deep royal Ethiopian forest green
val LuxuryDarkBg = Color(0xFF07140D)            // Cinematic near-black green
val LuxuryCardBg = Color(0xFF143021)            // Emerald translucent card base
val LuxuryGold = Color(0xFFD4AF37)              // Imperial gold accent
val LuxuryGoldLight = Color(0xFFE9D082)         // Warm luxury champagne highlights
val LuxuryAmber = Color(0xFFB8860B)             // Rich brownish gold shadows
val LuxuryTextLight = Color(0xFFF9F9F5)          // Smooth warm white text
val LuxuryTextMuted = Color(0xFFA5B8AC)          // Soft sage gray for structural texts
val LuxuryPlaceholder = Color(0xFF42574A)        // Deep accent outlines

val LuxuryLightGreen = Color(0xFF18422B)
val LuxuryLightBg = Color(0xFFFAF7F2)           // Soft warm ivory
val LuxuryLightCard = Color(0xFFFFFFFF)
val LuxuryLightText = Color(0xFF121C16)
