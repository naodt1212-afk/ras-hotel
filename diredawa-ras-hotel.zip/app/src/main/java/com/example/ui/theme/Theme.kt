package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable

private val DarkColorScheme = darkColorScheme(
    primary = LuxuryGold,
    onPrimary = LuxuryDarkGreen,
    primaryContainer = LuxuryLightGreen,
    onPrimaryContainer = LuxuryGoldLight,
    secondary = LuxuryGoldLight,
    onSecondary = LuxuryDarkBg,
    background = LuxuryDarkBg,
    onBackground = LuxuryTextLight,
    surface = LuxuryCardBg,
    onSurface = LuxuryTextLight,
    surfaceVariant = LuxuryDarkGreen,
    onSurfaceVariant = LuxuryTextMuted,
    outline = LuxuryPlaceholder
)

private val LightColorScheme = lightColorScheme(
    primary = LuxuryLightGreen,
    onPrimary = LuxuryTextLight,
    primaryContainer = LuxuryGoldLight,
    onPrimaryContainer = LuxuryLightGreen,
    secondary = LuxuryAmber,
    onSecondary = LuxuryTextLight,
    background = LuxuryLightBg,
    onBackground = LuxuryLightText,
    surface = LuxuryLightCard,
    onSurface = LuxuryLightText,
    surfaceVariant = LuxuryLightCard,
    onSurfaceVariant = LuxuryLightText,
    outline = LuxuryPlaceholder
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    // Keep dynamic color false so the custom luxury branding is consistently loaded
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
