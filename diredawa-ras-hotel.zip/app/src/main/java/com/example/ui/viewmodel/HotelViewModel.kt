package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.HotelDatabase
import com.example.data.model.BookingEntity
import com.example.data.model.FavoriteEntity
import com.example.data.model.UserEntity
import com.example.data.repository.HotelRepository
import com.example.ui.translation.AppLanguage
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlin.random.Random

sealed class HotelScreen {
    object Home : HotelScreen()
    object About : HotelScreen()
    object Rooms : HotelScreen()
    object Services : HotelScreen()
    object Gallery : HotelScreen()
    object Dining : HotelScreen()
    object Events : HotelScreen()
    object Offers : HotelScreen()
    object Booking : HotelScreen()
    object Contact : HotelScreen()
    object Auth : HotelScreen()
    object Dashboard : HotelScreen()
}

data class HotelRoom(
    val id: String,
    val titleKey: String,
    val price: Double,
    val imageUrl: String,
    val descKey: String,
    val size: String,
    val capacity: String,
    val bedType: String,
    val rating: Float
)

class HotelViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: HotelRepository

    init {
        val database = HotelDatabase.getDatabase(application)
        repository = HotelRepository(database.hotelDao())
    }

    // Language state
    private val _currentLanguage = MutableStateFlow(AppLanguage.EN)
    val currentLanguage: StateFlow<AppLanguage> = _currentLanguage.asStateFlow()

    fun setLanguage(language: AppLanguage) {
        _currentLanguage.value = language
    }

    // Active Screen state
    private val _activeScreen = MutableStateFlow<HotelScreen>(HotelScreen.Home)
    val activeScreen: StateFlow<HotelScreen> = _activeScreen.asStateFlow()

    fun navigateTo(screen: HotelScreen) {
        _activeScreen.value = screen
    }

    // Database flow bindings
    val allBookings: StateFlow<List<BookingEntity>> = repository.allBookings
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allFavorites: StateFlow<List<FavoriteEntity>> = repository.allFavorites
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Currently active authenticated session
    private val _currentUser = MutableStateFlow<UserEntity?>(null)
    val currentUser: StateFlow<UserEntity?> = _currentUser.asStateFlow()

    // Room database catalog definition
    val hotelRooms = listOf(
        HotelRoom(
            id = "deluxe",
            titleKey = "deluxe_room",
            price = 280.00,
            imageUrl = "https://images.unsplash.com/photo-1618773928121-c32242e63f39?auto=format&fit=crop&w=800&q=80",
            descKey = "room_desc_deluxe",
            size = "45 m²",
            capacity = "2 Adults",
            bedType = "1 King Bed",
            rating = 4.8f
        ),
        HotelRoom(
            id = "executive",
            titleKey = "executive_suite",
            price = 550.00,
            imageUrl = "https://images.unsplash.com/photo-1590490360182-c33d57733427?auto=format&fit=crop&w=800&q=80",
            descKey = "room_desc_exec",
            size = "85 m²",
            capacity = "3 Adults",
            bedType = "1 Presidential King",
            rating = 4.9f
        ),
        HotelRoom(
            id = "twin",
            titleKey = "standard_twin",
            price = 180.00,
            imageUrl = "https://images.unsplash.com/photo-1566665797739-1674de7a421a?auto=format&fit=crop&w=800&q=80",
            descKey = "room_desc_twin",
            size = "38 m²",
            capacity = "2 Adults",
            bedType = "2 Double Beds",
            rating = 4.5f
        ),
        HotelRoom(
            id = "presidential",
            titleKey = "presidential_suite",
            price = 1500.00,
            imageUrl = "https://images.unsplash.com/photo-1582719478250-c89cae4dc85b?auto=format&fit=crop&w=800&q=80",
            descKey = "room_desc_prez",
            size = "210 m²",
            capacity = "4 Adults",
            bedType = "2 Emperor King Beds + lounge",
            rating = 5.0f
        )
    )

    // Auth flows
    val emailInput = MutableStateFlow("")
    val passwordInput = MutableStateFlow("")
    val isOtpState = MutableStateFlow(false)
    val otpInput = MutableStateFlow("")
    val authError = MutableStateFlow<String?>(null)
    val authSuccessMsg = MutableStateFlow<String?>(null)
    val generatedOtp = MutableStateFlow("")

    init {
        // Auto-check active logged in session at startup
        viewModelScope.launch {
            val user = repository.getActiveUser()
            _currentUser.value = user
        }
    }

    // Toggle favorite room state
    fun toggleFavorite(roomName: String) {
        viewModelScope.launch {
            val isCurrentlyFav = allFavorites.value.any { it.roomName == roomName }
            repository.saveFavorite(roomName, !isCurrentlyFav)
        }
    }

    // Authenticate existing user
    fun login() {
        authError.value = null
        authSuccessMsg.value = null
        val email = emailInput.value.trim()
        val pwd = passwordInput.value

        if (email.isEmpty() || pwd.isEmpty()) {
            authError.value = "Please fill in all credentials"
            return
        }

        viewModelScope.launch {
            val user = repository.getUserByEmail(email)
            if (user == null) {
                authError.value = "User profile not found. Please Sign Up."
            } else if (user.passwordHash != pwd) {
                authError.value = "Invalid credentials. Try again."
            } else {
                // Succeeded! Set as logged-in session
                repository.logoutAll()
                val updatedUser = user.copy(isLoggedIn = true)
                repository.updateUser(updatedUser)
                _currentUser.value = updatedUser
                authSuccessMsg.value = "Welcome back, executive member!"
                navigateTo(HotelScreen.Dashboard)
            }
        }
    }

    // Sign up initiating simulated OTP
    fun signup() {
        authError.value = null
        authSuccessMsg.value = null
        val email = emailInput.value.trim()
        val pwd = passwordInput.value

        if (email.isEmpty() || pwd.length < 5) {
            authError.value = "Email cannot be empty and password must be at least 5 characters"
            return
        }

        viewModelScope.launch {
            val existing = repository.getUserByEmail(email)
            if (existing != null) {
                authError.value = "Account already exists for this email"
                return@launch
            }

            // Generate a simulated, deterministic OTP code based on legacy times (e.g. 1968) or random
            val code = (100000 + Random.nextInt(900000)).toString()
            generatedOtp.value = code
            val simulatedUser = UserEntity(
                email = email,
                passwordHash = pwd,
                isVerified = false,
                verificationCode = code,
                isLoggedIn = false
            )
            repository.registerUser(simulatedUser)
            isOtpState.value = true
            authSuccessMsg.value = "Security OTP security code dispatched! (Code: $code)"
        }
    }

    // Confirm OTP verification code
    fun verifyOtp() {
        authError.value = null
        authSuccessMsg.value = null
        val email = emailInput.value.trim()
        val enteredCode = otpInput.value.trim()

        viewModelScope.launch {
            val user = repository.getUserByEmail(email)
            if (user == null) {
                authError.value = "Verification context lost. Register again."
                isOtpState.value = false
                return@launch
            }

            if (user.verificationCode == enteredCode) {
                // Successfully verified & automatically log in!
                repository.logoutAll()
                val verifiedUser = user.copy(isVerified = true, isLoggedIn = true)
                repository.updateUser(verifiedUser)
                _currentUser.value = verifiedUser
                isOtpState.value = false
                emailInput.value = ""
                passwordInput.value = ""
                otpInput.value = ""
                authSuccessMsg.value = "Account verified and registered successfully!"
                navigateTo(HotelScreen.Dashboard)
            } else {
                authError.value = "Incorrect OTP verification code"
            }
        }
    }

    // Log out current session
    fun logout() {
        viewModelScope.launch {
            repository.logoutAll()
            _currentUser.value = null
            authSuccessMsg.value = null
            navigateTo(HotelScreen.Home)
        }
    }

    // Clear local booking database records
    fun clearBookings() {
        viewModelScope.launch {
            repository.clearBookings()
        }
    }

    // Active reservation helper states
    val checkInDate = MutableStateFlow("2026-05-27")
    val checkOutDate = MutableStateFlow("2026-05-30")
    val guestCount = MutableStateFlow(2)
    val selectedBookingRoom = MutableStateFlow<HotelRoom?>(null)

    // Complete local booking reservation
    fun executeBooking(paymentMethod: String, status: String = "Confirmed") {
        val room = selectedBookingRoom.value ?: return
        val nights = calculateNights(checkInDate.value, checkOutDate.value)
        val totalPrice = room.price * nights * (if (guestCount.value > room.capacity.first().digitToIntOrNull() ?: 1) 1.2 else 1.0)

        viewModelScope.launch {
            val newBooking = BookingEntity(
                roomName = room.titleKey,
                checkIn = checkInDate.value,
                checkOut = checkOutDate.value,
                guests = guestCount.value,
                totalPrice = totalPrice,
                paymentMethod = paymentMethod,
                status = status
            )
            repository.createBooking(newBooking)
            // Save state & navigate back to dashboard/history
            selectedBookingRoom.value = null
            navigateTo(HotelScreen.Dashboard)
        }
    }

    // Simple night count calculation helper
    fun calculateNights(start: String, end: String): Int {
        return try {
            val sDateNum = start.substringAfterLast("-").toIntOrNull() ?: 1
            val eDateNum = end.substringAfterLast("-").toIntOrNull() ?: 4
            val result = eDateNum - sDateNum
            if (result <= 0) 1 else result
        } catch (e: Exception) {
            3
        }
    }
}
