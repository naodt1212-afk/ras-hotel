package com.example.data.repository

import com.example.data.local.HotelDao
import com.example.data.model.BookingEntity
import com.example.data.model.FavoriteEntity
import com.example.data.model.UserEntity
import kotlinx.coroutines.flow.Flow

class HotelRepository(private val hotelDao: HotelDao) {

    // Bookings flows & methods
    val allBookings: Flow<List<BookingEntity>> = hotelDao.getAllBookingsFlow()

    suspend fun createBooking(booking: BookingEntity) {
        hotelDao.insertBooking(booking)
    }

    suspend fun clearBookings() {
        hotelDao.clearAllBookings()
    }

    // Favorites flows & methods
    val allFavorites: Flow<List<FavoriteEntity>> = hotelDao.getAllFavoritesFlow()

    suspend fun saveFavorite(roomName: String, isFav: Boolean) {
        if (isFav) {
            hotelDao.insertFavorite(FavoriteEntity(roomName, true))
        } else {
            hotelDao.deleteFavorite(roomName)
        }
    }

    // Authenticated Users methods
    suspend fun getUserByEmail(email: String): UserEntity? {
        return hotelDao.getUserByEmail(email)
    }

    suspend fun getActiveUser(): UserEntity? {
        return hotelDao.getActiveUser()
    }

    suspend fun registerUser(user: UserEntity) {
        hotelDao.insertUser(user)
    }

    suspend fun updateUser(user: UserEntity) {
        hotelDao.updateUser(user)
    }

    suspend fun logoutAll() {
        hotelDao.logoutAllUsers()
    }
}
